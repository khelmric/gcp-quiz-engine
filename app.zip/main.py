import secrets
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from flask import Flask, render_template, request, redirect, url_for, flash, make_response
app = Flask(__name__)

# vars
main_categories = []
app.secret_key = secrets.token_urlsafe(16)
selected_main_category_id = ""

# Use the application default credentials.
cred = credentials.ApplicationDefault()
firebase_admin.initialize_app(cred)
db = firestore.client()

db_ref = db.collection(u'quiz-db')
firestore_main_categories = db_ref.where('type', '==', 'main-category')

@app.route('/', methods=['GET', 'POST'])

@app.route('/index', methods=['GET', 'POST'])
def index():
#    if doc.exists:
#        text_entry = 'Document found!'
#    else:
#        text_entry = 'No such document!'

    return render_template('index.html', main_categories=main_categories, selected_main_category_id=selected_main_category_id)

@app.route('/setcookie', methods=['GET', 'POST'])
def setcookie():
   if request.method == 'POST':
       selected_main_category_id = request.form['selected_main_category_id']
   resp = make_response(render_template('index.html'))
   resp.set_cookie('selected_main_category_id', selected_main_category_id)
 
   return render_template('index.html', main_categories=main_categories, selected_main_category_id=selected_main_category_id)  
#   return resp

@app.route('/getcookie')
def getcookie():
   name = request.cookies.get('selected_main_category_id')
   return render_template('index.html', main_categories=main_categories, selected_main_category_id=selected_main_category_id)


if __name__ == '__main__':
    for main_category in firestore_main_categories.stream():
        main_categories.append((main_category.to_dict()))
    app.run(debug=True, host='0.0.0.0', port=8080)
